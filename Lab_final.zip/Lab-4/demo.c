#include <stdio.h>

// Single line comment

int main() {
    // Single line comment
    printf("Hello, World!\n"); // Single line comment
    return 0;
}

/*
Multi-line comment
*/