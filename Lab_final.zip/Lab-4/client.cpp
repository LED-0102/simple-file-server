#include <iostream>
#include <arpa/inet.h>
#include <unistd.h>
#include <cstring>
#include <chrono>

#define SERVER_IP "127.0.0.1"  // Change to actual server IP if needed
#define SERVER_PORT 8080        // Server port
#define NUM_PINGS 10            // Number of ping requests

int main() {
    int clientSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (clientSocket == -1) {
        std::cerr << "Error creating socket\n";
        return -1;
    }

    sockaddr_in serverAddr{};
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr(SERVER_IP);
    serverAddr.sin_port = htons(SERVER_PORT);

    char buffer[1024];
    struct timeval timeout = {1, 0};  // Set timeout of 1 second
    setsockopt(clientSocket, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));

    for (int i = 1; i <= NUM_PINGS; ++i) {
        std::string message = "Ping " + std::to_string(i);
        auto start = std::chrono::high_resolution_clock::now();

        sendto(clientSocket, message.c_str(), message.size(), 0,
               (struct sockaddr*)&serverAddr, sizeof(serverAddr));

        sockaddr_in responseAddr{};
        socklen_t addrLen = sizeof(responseAddr);
        ssize_t bytesReceived = recvfrom(clientSocket, buffer, sizeof(buffer), 0,
                                         (struct sockaddr*)&responseAddr, &addrLen);

        if (bytesReceived == -1) {
            std::cout << "Ping " << i << " timed out.\n";
        } else {
            auto end = std::chrono::high_resolution_clock::now();
            std::chrono::duration<double> elapsed = end - start;
            buffer[bytesReceived] = '\0';  // Null-terminate the response
            std::cout << "Received: " << buffer << " | RTT: " << elapsed.count() << " sec\n";
        }

        sleep(1);  // Wait 1 second before next ping
    }

    close(clientSocket);
    return 0;
}
