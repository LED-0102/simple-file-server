#include <iostream>
#include <arpa/inet.h>
#include <unistd.h>
#include <cstring>

#define PORT 8080  // Server port

int main() {
    int serverSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (serverSocket == -1) {
        std::cerr << "Error creating socket\n";
        return -1;
    }

    sockaddr_in serverAddr{}, clientAddr{};
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(PORT);

    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == -1) {
        std::cerr << "Error binding socket\n";
        close(serverSocket);
        return -1;
    }

    char buffer[1024];
    socklen_t clientAddrLen = sizeof(clientAddr);

    std::cout << "Server is running on port " << PORT << "...\n";

    while (true) {
        ssize_t bytesRead = recvfrom(serverSocket, buffer, sizeof(buffer), 0,
                                     (struct sockaddr*)&clientAddr, &clientAddrLen);
        if (bytesRead == -1) {
            std::cerr << "Error receiving data\n";
            continue;
        }

        buffer[bytesRead] = '\0';  // Null-terminate received message
        std::cout << "Received: " << buffer << " from client\n";

        // Send response
        std::string response = "Pong";
        sendto(serverSocket, response.c_str(), response.size(), 0,
               (struct sockaddr*)&clientAddr, clientAddrLen);
    }

    close(serverSocket);
    return 0;
}
