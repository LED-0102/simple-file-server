Commands to run q1
yacc -d q1.y
lex q1.l
gcc lex.yy.c y.tab.c -o parser -ll
./parser

Commands to run q2
yacc -d q2.y
lex q2.l
gcc lex.yy.c y.tab.c -o parser -ll
./parser
