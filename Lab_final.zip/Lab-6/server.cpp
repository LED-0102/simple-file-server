#include <iostream>
#include <cstring>
#include <cstdlib>
#include <unistd.h>
#include <arpa/inet.h>
#include <ctime>
#include <thread>

#define SERVER_PORT 8080
#define BUFFER_SIZE 1024

bool requiresPrivilegeEscalation(const std::string& command) {
    return command.find("sudo") == 0 || command.find("rm -rf") != std::string::npos || 
           command.find("passwd") != std::string::npos || command.find("shutdown") != std::string::npos ||
           command.find("reboot") != std::string::npos;
}

void handleClient(int clientSocket) {
    char buffer[BUFFER_SIZE];
    
    time_t now = time(0);
    std::string serverInfo = "Server IP: 127.0.0.1, Time: " + std::string(ctime(&now));
    send(clientSocket, serverInfo.c_str(), serverInfo.length(), 0);
    
    while (true) {
        memset(buffer, 0, BUFFER_SIZE);
        int bytesReceived = recv(clientSocket, buffer, BUFFER_SIZE, 0);
        if (bytesReceived <= 0) {
            break;
        }
        
        std::string command(buffer);

        std::cout<<"Command received: "<<command<<std::endl;
        if (command == "exit") {
            std::cout<<"Client Disconnected\n";
            break;
        }
        
        if (requiresPrivilegeEscalation(command)) {
            std::string errorMsg = "Error: Command requires privilege escalation and is not allowed.";
            send(clientSocket, errorMsg.c_str(), errorMsg.length(), 0);
            continue;
        }
        
        std::string result;
        FILE* pipe = popen(command.c_str(), "r");
        if (pipe) {
            char tempBuffer[BUFFER_SIZE];
            while (fgets(tempBuffer, BUFFER_SIZE, pipe) != nullptr) {
                result += tempBuffer;
            }
            pclose(pipe);
        } else {
            result = "Error executing command.";
        }
        
        if (result.empty()) {
            result = "Command executed successfully with no output.";
        }
        
        send(clientSocket, result.c_str(), result.length(), 0);
    }
    
    close(clientSocket);
}

int main() {
    int serverSocket, clientSocket;
    struct sockaddr_in serverAddr, clientAddr;
    socklen_t addrSize = sizeof(clientAddr);
    
    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == -1) {
        std::cerr << "Error creating socket!" << std::endl;
        return 1;
    }
    
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(SERVER_PORT);
    
    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == -1) {
        std::cerr << "Binding failed!" << std::endl;
        return 1;
    }
    
    if (listen(serverSocket, 5) == -1) {
        std::cerr << "Listening failed!" << std::endl;
        return 1;
    }
    
    std::cout << "Server is running on port " << SERVER_PORT << "..." << std::endl;
    
    while (true) {
        clientSocket = accept(serverSocket, (struct sockaddr*)&clientAddr, &addrSize);
        if (clientSocket == -1) {
            std::cerr << "Client connection failed!" << std::endl;
            continue;
        }
        
        std::cout << "Client connected!" << std::endl;
        
        std::thread clientThread(handleClient, clientSocket);
        clientThread.detach();
    }
    
    close(serverSocket);
    return 0;
}
