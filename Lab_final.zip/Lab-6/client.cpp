#include <iostream>
#include <cstring>
#include <cstdlib>
#include <unistd.h>
#include <arpa/inet.h>

#define SERVER_PORT 8080
#define BUFFER_SIZE 1024

int main() {
    int clientSocket;
    struct sockaddr_in serverAddr;
    char buffer[BUFFER_SIZE];

    clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket == -1) {
        std::cerr << "Error creating socket!" << std::endl;
        return 1;
    }

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(SERVER_PORT);
    serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1"); // Change to server's IP if needed

    if (connect(clientSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == -1) {
        std::cerr << "Connection failed!" << std::endl;
        return 1;
    }

    recv(clientSocket, buffer, BUFFER_SIZE, 0);
    std::cout << "Server Info: " << buffer << std::endl;

    while (true) {
        std::cout << "Enter command (or 'exit' to quit): ";
        std::string command;
        std::getline(std::cin, command);

        send(clientSocket, command.c_str(), command.length(), 0);
        
        if (command == "exit") {
            break;
        }

        memset(buffer, 0, BUFFER_SIZE);
        recv(clientSocket, buffer, BUFFER_SIZE, 0);
        std::cout << "Server Response: " << buffer << std::endl;
    }

    close(clientSocket);
    return 0;
}
