#include <stdio.h>
#include <string.h>
#include <ctype.h>

// Function to check if a string is a palindrome after filtering non-alphanumeric characters
int isPalindrome(char str[], int len) {
    int left = 0, right = len - 1;
    
    while (left < right) {
        // Ignore non-alphanumeric characters
        while (left < right && !isalnum(str[left])) left++;
        while (left < right && !isalnum(str[right])) right--;
        
        // Convert to lowercase and compare
        if (tolower(str[left]) != tolower(str[right])) 
            return 0;
        
        left++;
        right--;
    }
    return 1;
}

// Function to rotate the string left by one position
void rotateLeft(char str[], int len) {
    if (len <= 1) return;
    
    char first = str[0];
    for (int i = 0; i < len - 1; i++) {
        str[i] = str[i + 1];
    }
    str[len - 1] = first;
}

// Function to check if any rotation of the string is a palindrome
int isRotatedPalindrome(char str[]) {
    int len = strlen(str);
    
    // Check all rotations
    for (int i = 0; i < len; i++) {
        if (isPalindrome(str, len)) {
            return 1;  // Found a palindrome rotation
        }
        rotateLeft(str, len);  // Rotate the string left by one
    }
    
    return 0;  // No palindrome rotation found
}

// Driver code
int main() {
    char str[] = "cdcbaab";  // Example input
    
    if (isRotatedPalindrome(str))
        printf("The string \"%s\" is a rotated palindrome.\n", str);
    else
        printf("The string \"%s\" is NOT a rotated palindrome.\n", str);

    return 0;
}
