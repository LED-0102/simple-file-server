#include <stdio.h>
#include <stdlib.h>

// Function to find the index using binary search (lower bound logic)
int lowerBound(int arr[], int size, int key) {
    int left = 0, right = size - 1;
    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (arr[mid] >= key)
            right = mid - 1;
        else
            left = mid + 1;
    }
    return left;
}

// Function to find the length of the Longest Increasing Subsequence
int lengthOfLIS(int arr[], int n) {
    if (n == 0) return 0;

    int *tail = (int *)malloc(n * sizeof(int));
    int length = 0;  // Represents the length of the LIS

    for (int i = 0; i < n; i++) {
        int pos = lowerBound(tail, length, arr[i]); // Find position to replace or extend

        tail[pos] = arr[i];

        // If the element is placed at the end, increase LIS length
        if (pos == length)
            length++;
    }

    free(tail);
    return length;
}

// Driver code
int main() {
    int arr[] = {10, 9, 2, 5, 3, 7, 101, 18};
    int n = sizeof(arr) / sizeof(arr[0]);

    printf("Length of Longest Increasing Subsequence: %d\n", lengthOfLIS(arr, n));

    return 0;
}
