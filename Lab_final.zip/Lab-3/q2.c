#include <stdio.h>

// Function to swap two elements
void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

// Function to find the smallest missing positive integer
int findSmallestMissingPositive(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        // Place each number in its correct index if it's within range
        while (arr[i] > 0 && arr[i] <= n && arr[i] != arr[arr[i] - 1]) {
            swap(&arr[i], &arr[arr[i] - 1]);
        }
    }

    // Find the first missing number
    for (int i = 0; i < n; i++) {
        if (arr[i] != i + 1) {
            return i + 1;
        }
    }

    // If all numbers are present in sequence, return n + 1
    return n + 1;
}

// Driver code
int main() {
    int arr[] = {3, 4, -1, 1};
    int n = sizeof(arr) / sizeof(arr[0]);

    printf("Smallest Missing Positive Integer: %d\n", findSmallestMissingPositive(arr, n));

    return 0;
}
