#include <stdio.h>
#include <ctype.h>
#include <string.h>
#define MAX_TOKEN_LENGTH 100
// Define an array of C keywords that we want to identify
const char* keywords[] = {
"int", "float", "double", "char", "return", "if", "else", "while", "for", "break",
"continue", "switch", "case", "default", "void", "struct", "union", "long", "short",
"typedef", "const", "goto"
};
#define NUM_KEYWORDS (sizeof(keywords) / sizeof(keywords[0])) // Number of keywords
// Function to check if a token is a keyword
int is_keyword(const char* token) {
// Iterate through the array of keywords and check if the token matches any of them
for (int i = 0; i < NUM_KEYWORDS; i++) {
if (strcmp(token, keywords[i]) == 0) {
return 1; // Token is a keyword
}
}
return 0; // Token is not a keyword
}
// Function to check if a character is an operator
int is_operator(char c) {

// Define a string containing all possible operators in C
char operators[] = "+-*/%=&|^<>!";
// Check if the character matches any operator in the list
for (int i = 0; operators[i] != '\0'; i++) {
if (c == operators[i]) {
return 1; // Character is an operator
}
}
return 0; // Character is not an operator
}
// Function to skip over string literals in the code
void skip_string_literal(FILE* file) {
char c;
// Continue reading characters until we reach the closing double-quote of the string literal
while ((c = fgetc(file)) != EOF) {
if (c == '"') {
break; // End of string literal
}
}
}
// Function to identify tokens in the C file
void identify_tokens(FILE* file) {
char c;
char token[MAX_TOKEN_LENGTH]; // Array to store the current token
int i = 0; // Index for the token array
// Read each character from the file until we reach the end
while ((c = fgetc(file)) != EOF) {
// Skip preprocessor directives (e.g., #include) and the rest of the line
if (c == '#') {
while ((c = fgetc(file)) != EOF && c != '\n') {
// Skip characters inside preprocessor directive
}
continue; // Move to the next character after the directive
}
// Skip over string literals (e.g., "Hello World") and treat them as a single token
if (c == '"') {
skip_string_literal(file);
continue;
}
// Handle whitespace (spaces, tabs, newlines)
if (isspace(c)) {

// If there's a valid token accumulated, process it
if (i > 0) {
token[i] = '\0'; // Null-terminate the token
if (is_keyword(token)) {
printf("Keyword: %s\n", token); // Print keyword if the token is a keyword
} else if (isalpha(token[0]) || token[0] == '_') {
printf("Identifier: %s\n", token); // Print identifier if it's a valid identifier
} else if (isdigit(token[0])) {
printf("Number: %s\n", token); // Print number if the token starts with a digit
}
i = 0; // Reset the token index for the next token
}
continue;
}
// Handle operators (e.g., +, -, *, /)
if (is_operator(c)) {
// If there's a token accumulated before encountering an operator, process it
if (i > 0) {
token[i] = '\0'; // Null-terminate the token
if (is_keyword(token)) {
printf("Keyword: %s\n", token);
} else if (isalpha(token[0]) || token[0] == '_') {
printf("Identifier: %s\n", token);
} else if (isdigit(token[0])) {
printf("Number: %s\n", token);
}
i = 0; // Reset the token index
}
// Print the operator and continue to the next character
printf("Operator: %c\n", c);
continue;
}
// If the character is part of an alphanumeric sequence or an underscore, accumulate it
if (isalnum(c) || c == '_') {
token[i++] = c; // Add the character to the token array
continue;
}
// Handle punctuation characters (e.g., semicolons, parentheses)
if (ispunct(c)) {
// If a token has been accumulated, process it
if (i > 0) {
token[i] = '\0'; // Null-terminate the token
if (is_keyword(token)) {
printf("Keyword: %s\n", token);
} else if (isalpha(token[0]) || token[0] == '_') {

printf("Identifier: %s\n", token);
} else if (isdigit(token[0])) {
printf("Number: %s\n", token);
}
i = 0; // Reset the token index
}
// Ignore punctuation characters for now
}
}
// Check for any remaining token after the loop ends
if (i > 0) {
token[i] = '\0'; // Null-terminate the final token
if (is_keyword(token)) {
printf("Keyword: %s\n", token);
} else if (isalpha(token[0]) || token[0] == '_') {
printf("Identifier: %s\n", token);
} else if (isdigit(token[0])) {
printf("Number: %s\n", token);
}
}
}
// Main function to drive the program
int main() {
char filename[100]; // Array to hold the filename input
printf("Enter the C file name: ");
scanf("%s", filename); // Take input for the C file name
// Open the file in read mode
FILE* file = fopen(filename, "r");
if (file == NULL) { // Check if the file opened successfully
printf("Error opening file.\n");
return 1; // Exit with an error code if file can't be opened
}
// Call the function to identify tokens in the file
identify_tokens(file);
fclose(file); // Close the file after processing
return 0; // Return 0 to indicate successful completion
}