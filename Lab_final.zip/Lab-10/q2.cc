#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/csma-module.h"
#include "ns3/internet-module.h"
#include "ns3/applications-module.h"
#include "ns3/flow-monitor-module.h"

using namespace std;
using namespace ns3;

int main (int argc, char* argv[]) {
    string csmaDelay = "1ms";

    NodeContainer csmaNodes;
    csmaNodes.Create (4);

    CsmaHelper csma;
    csma.SetChannelAttribute ("DataRate", StringValue ("100Mbps"));
    csma.SetChannelAttribute ("Delay", StringValue (csmaDelay));

    NetDeviceContainer csmaDevices;
    csmaDevices = csma.Install (csmaNodes);

    InternetStackHelper stack;
    stack.Install (csmaNodes);

    Ipv4AddressHelper address;
    address.SetBase ("10.1.2.0", "255.255.255.0");

    Ipv4InterfaceContainer interfaces = address.Assign (csmaDevices);



    UdpEchoServerHelper echoServer (5001);
    ApplicationContainer serverApp = echoServer.Install (csmaNodes.Get(1));

    serverApp.Start (Seconds(1.0));
    serverApp.Stop (Seconds(10.0));

    UdpEchoClientHelper echoClient (interfaces.GetAddress(1), 5001);
    echoClient.SetAttribute ("MaxPackets", UintegerValue (5));
    echoClient.SetAttribute ("Interval", TimeValue (Seconds (1.0)));
    echoClient.SetAttribute ("PacketSize", UintegerValue (1024));


    ApplicationContainer clientApp = echoClient.Install (csmaNodes.Get(0));

    csma.EnablePcapAll ("scratch/q2/csma-lan");

    FlowMonitorHelper flowmon;
    auto monitor = flowmon.InstallAll();

    Simulator::Stop (Seconds(10.0));

    Simulator::Run();

    monitor->CheckForLostPackets ();
    Ptr<Ipv4FlowClassifier> classifier = DynamicCast<Ipv4FlowClassifier> (flowmon.GetClassifier ());
    std::map<FlowId, FlowMonitor::FlowStats> stats = monitor->GetFlowStats ();

    for (auto const& flow : stats) {
        Ipv4FlowClassifier::FiveTuple t = classifier->FindFlow (flow.first);
        std::cout << "Flow " << flow.first << " (" << t.sourceAddress << " -> " << t.destinationAddress << ")\n";
        std::cout << "  Tx Bytes: " << flow.second.txBytes << "\n";
        std::cout << "  Rx Bytes: " << flow.second.rxBytes << "\n";
        std::cout << "  Delay (avg): " << flow.second.delaySum.GetSeconds () / flow.second.rxPackets << " s\n";
        std::cout << "  Throughput: " << flow.second.rxBytes * 8.0 / (flow.second.timeLastRxPacket.GetSeconds () - flow.second.timeFirstTxPacket.GetSeconds ()) / 1000000 << " Mbps\n";
    }

    Simulator::Destroy ();
    return 0;
}