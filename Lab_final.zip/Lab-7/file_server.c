#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <dirent.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/socket.h>

#define PORT 8080
#define BUFFER_SIZE 100
#define DIRECTORY "./"

void log_message(const char *message) {
    printf("[SERVER] %s\n", message);
}

void list_files(int client_sock) {
    DIR *dir;
    struct dirent *entry;
    char buffer[BUFFER_SIZE];

    log_message("Client requested file list.");
    if ((dir = opendir(DIRECTORY)) == NULL) {
        perror("opendir failed");
        return;
    }

    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_REG) {
            snprintf(buffer, BUFFER_SIZE, "%s\n", entry->d_name);
            send(client_sock, buffer, strlen(buffer), 0);
        }
    }
    closedir(dir);
    send(client_sock, "END\n", 4, 0);  // Indicate end of list
    log_message("File list sent.");
}

void send_file(int client_sock, char *filename) {
    char filepath[256];
    snprintf(filepath, sizeof(filepath), "%s%s", DIRECTORY, filename);

    int file_fd = open(filepath, O_RDONLY);
    if (file_fd < 0) {
        log_message("File not found.");
        send(client_sock, "ERROR: File Not Found\n", 23, 0);
        return;
    }

    log_message("Sending file to client.");
    char buffer[BUFFER_SIZE];
    ssize_t bytes_read;

    while ((bytes_read = read(file_fd, buffer, BUFFER_SIZE)) > 0) {
        send(client_sock, buffer, bytes_read, 0);
    }
    close(file_fd);

    // Send "EOF" as a separate message
    send(client_sock, "EOF", 3, 0);
    log_message("File transfer complete.");
}

void handle_client(int client_sock) {
    char buffer[BUFFER_SIZE];
    send(client_sock, "Welcome to Simple File Server\n", 30, 0);

    while (1) {
        memset(buffer, 0, BUFFER_SIZE);
        int received = recv(client_sock, buffer, BUFFER_SIZE, 0);
        if (received <= 0) {
            log_message("Client disconnected.");
            break;
        }

        log_message(buffer);

        if (strncmp(buffer, "LIST", 4) == 0) {
            list_files(client_sock);
        } else if (strncmp(buffer, "GET ", 4) == 0) {
            send_file(client_sock, buffer + 4);
        } else if (strncmp(buffer, "QUIT", 4) == 0) {
            log_message("Client requested to quit.");
            break;
        }
    }
    close(client_sock);
}

int main() {
    int server_sock, client_sock;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);

    server_sock = socket(AF_INET, SOCK_STREAM, 0);
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    bind(server_sock, (struct sockaddr*)&server_addr, sizeof(server_addr));
    listen(server_sock, 5);
    log_message("Server started, waiting for connections...");

    while ((client_sock = accept(server_sock, (struct sockaddr*)&client_addr, &addr_len))) {
        log_message("Client connected.");
        if (!fork()) {
            close(server_sock);
            handle_client(client_sock);
            exit(0);
        }
        close(client_sock);
    }
    close(server_sock);
    return 0;
}
