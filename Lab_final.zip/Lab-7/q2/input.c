#include <stdio.h>

int main() {
    printf("Hello, world!");
    if (1) {
        printf("Test");
    }
    return 0;
}
