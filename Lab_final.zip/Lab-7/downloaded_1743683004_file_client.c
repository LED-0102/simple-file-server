#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <time.h>

#define SERVER_IP "127.0.0.1"
#define PORT 8080
#define BUFFER_SIZE 100

void save_file(int sock, char *filename) {
    char buffer[BUFFER_SIZE + 1];  // Extra byte for null termination
    ssize_t bytes_received;

    // Generate a unique filename with timestamp
    time_t now = time(NULL);
    char new_filename[256];
    snprintf(new_filename, sizeof(new_filename), "downloaded_%ld_%s", now, filename);

    int file_fd = open(new_filename, O_WRONLY | O_CREAT | O_TRUNC, 0666);
    if (file_fd < 0) {
        perror("Failed to create file");
        return;
    }

    printf("Receiving file: %s\n", new_filename);

    while ((bytes_received = recv(sock, buffer, BUFFER_SIZE, 0)) > 0) {
        buffer[bytes_received] = '\0';  // Null-terminate the buffer for easier detection
        if (bytes_received >= 3 && strcmp(buffer + bytes_received - 3, "EOF") == 0) {
            write(file_fd, buffer, bytes_received - 3);  // Remove EOF from the write
            break;  // End of file detected
        }
        write(file_fd, buffer, bytes_received);
    }

    close(file_fd);
    printf("File transfer complete.\n");
}

int main() {
    int sock;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE];

    sock = socket(AF_INET, SOCK_STREAM, 0);
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr);

    connect(sock, (struct sockaddr*)&server_addr, sizeof(server_addr));
    recv(sock, buffer, BUFFER_SIZE, 0);
    printf("%s", buffer);

    while (1) {
        printf("Enter command (LIST, GET <filename>, QUIT): ");
        memset(buffer, 0, BUFFER_SIZE);
        fgets(buffer, BUFFER_SIZE, stdin);
        buffer[strcspn(buffer, "\n")] = 0;

        send(sock, buffer, strlen(buffer), 0);

        if (strncmp(buffer, "LIST", 4) == 0) {
            while (1) {
                memset(buffer, 0, BUFFER_SIZE);
                recv(sock, buffer, BUFFER_SIZE, 0);
                printf("%s", buffer);
                if (strncmp(buffer, "END\n", 4) == 0) break;
            }
        } else if (strncmp(buffer, "GET ", 4) == 0) {
            save_file(sock, buffer + 4);
        } else if (strncmp(buffer, "QUIT", 4) == 0) {
            break;
        }
    }

    close(sock);
    return 0;
}
