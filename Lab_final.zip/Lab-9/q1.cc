#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/error-model.h"

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("ModifiedFourNodeSim");

int main(int argc, char *argv[]) {

    // Define four individual nodes
    NodeContainer topology;
    topology.Create(4);

    // Helper to configure links between nodes
    PointToPointHelper p2pHelper;
    p2pHelper.SetDeviceAttribute("DataRate", StringValue("1Mbps"));
    p2pHelper.SetChannelAttribute("Delay", StringValue("1ms"));

    // Connect nodes using p2p links
    NetDeviceContainer linkA = p2pHelper.Install(topology.Get(0), topology.Get(1));
    NetDeviceContainer linkB = p2pHelper.Install(topology.Get(1), topology.Get(2));
    NetDeviceContainer linkC = p2pHelper.Install(topology.Get(2), topology.Get(3));

    // Inject error model on linkB (from Node1 to Node2)
    Ptr<RateErrorModel> errModel = CreateObject<RateErrorModel>();
    errModel->SetAttribute("ErrorRate", DoubleValue(1e-7));
    errModel->SetAttribute("ErrorUnit", StringValue("ERROR_UNIT_BIT"));
    linkB.Get(1)->SetAttribute("ReceiveErrorModel", PointerValue(errModel));

    // Install internet stack on all nodes
    InternetStackHelper inetStack;
    inetStack.Install(topology);

    // Enable packet forwarding on intermediate nodes
    for (uint32_t i = 1; i < 3; ++i) {
        Ptr<Ipv4> ip = topology.Get(i)->GetObject<Ipv4>();
        ip->SetAttribute("IpForward", BooleanValue(true));
    }

    // Assign unique IPs for each network segment
    Ipv4AddressHelper addrHelper;
    addrHelper.SetBase("192.168.1.0", "255.255.255.0");
    Ipv4InterfaceContainer ifaceA = addrHelper.Assign(linkA);

    addrHelper.SetBase("192.168.2.0", "255.255.255.0");
    Ipv4InterfaceContainer ifaceB = addrHelper.Assign(linkB);

    addrHelper.SetBase("192.168.3.0", "255.255.255.0");
    Ipv4InterfaceContainer ifaceC = addrHelper.Assign(linkC);

    // Create routing tables
    Ipv4GlobalRoutingHelper::PopulateRoutingTables();

    // ---------- Deploy Application Layer ------------

    // UDP stream #1: Node0 -> Node2
    UdpServerHelper serverOne(6000);
    ApplicationContainer srvAppOne = serverOne.Install(topology.Get(2));
    srvAppOne.Start(Seconds(0.5));
    srvAppOne.Stop(Seconds(9.5));

    UdpClientHelper clientOne(ifaceB.GetAddress(1), 6000);
    clientOne.SetAttribute("MaxPackets", UintegerValue(1000));
    clientOne.SetAttribute("Interval", TimeValue(MilliSeconds(10)));
    clientOne.SetAttribute("PacketSize", UintegerValue(1024));
    ApplicationContainer cliAppOne = clientOne.Install(topology.Get(0));
    cliAppOne.Start(Seconds(1.5));
    cliAppOne.Stop(Seconds(9.0));

    // UDP stream #2: Node0 -> Node3
    UdpServerHelper serverTwo(6001);
    ApplicationContainer srvAppTwo = serverTwo.Install(topology.Get(3));
    srvAppTwo.Start(Seconds(0.5));
    srvAppTwo.Stop(Seconds(9.5));

    UdpClientHelper clientTwo(ifaceC.GetAddress(1), 6001);
    clientTwo.SetAttribute("MaxPackets", UintegerValue(1000));
    clientTwo.SetAttribute("Interval", TimeValue(MilliSeconds(10)));
    clientTwo.SetAttribute("PacketSize", UintegerValue(1024));
    ApplicationContainer cliAppTwo = clientTwo.Install(topology.Get(0));
    cliAppTwo.Start(Seconds(1.5));
    cliAppTwo.Stop(Seconds(9.0));

    // Capture packets on links for analysis
    p2pHelper.EnablePcap("scratch/q1/node0-1", linkA.Get(0), true);
    p2pHelper.EnablePcap("scratch/q1/node1-2", linkB.Get(0), true);
    p2pHelper.EnablePcap("scratch/q1/node2-3", linkC.Get(0), true);

    // Attach flow monitor to collect stats
    FlowMonitorHelper monitorHelper;
    Ptr<FlowMonitor> flowMonitor = monitorHelper.InstallAll();

    Simulator::Stop(Seconds(10.0));
    Simulator::Run();

    // Review flow statistics
    flowMonitor->CheckForLostPackets();
    Ptr<Ipv4FlowClassifier> classifier = DynamicCast<Ipv4FlowClassifier>(monitorHelper.GetClassifier());
    auto stats = flowMonitor->GetFlowStats();

    for (const auto& entry : stats) {
        auto tuple = classifier->FindFlow(entry.first);
        std::cout << "Flow " << entry.first << " [" 
                  << tuple.sourceAddress << " -> " << tuple.destinationAddress << "]\n";
        std::cout << "  Transmitted: " << entry.second.txPackets << "\n";
        std::cout << "  Received:    " << entry.second.rxPackets << "\n";
        std::cout << "  Lost:        " << entry.second.txPackets - entry.second.rxPackets << "\n";
        std::cout << "  Loss Ratio:  " 
                  << (100.0 * (entry.second.txPackets - entry.second.rxPackets) / entry.second.txPackets)
                  << "%\n\n";
    }

    Simulator::Destroy();
    return 0;
}
