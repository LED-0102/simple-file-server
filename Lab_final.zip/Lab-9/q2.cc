#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/ipv4-global-routing-helper.h"

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("MultiTrafficSimulation");

int main(int argc, char *argv[]) {

    // Create 3 nodes: A - B - C
    NodeContainer netNodes;
    netNodes.Create(3);

    // Configure bottleneck link between nodes
    PointToPointHelper p2pLink;
    p2pLink.SetDeviceAttribute("DataRate", StringValue("2Mbps")); // lower to force congestion
    p2pLink.SetChannelAttribute("Delay", StringValue("5ms")); // slightly higher delay

    NetDeviceContainer linkA_B = p2pLink.Install(netNodes.Get(0), netNodes.Get(1));
    NetDeviceContainer linkB_C = p2pLink.Install(netNodes.Get(1), netNodes.Get(2));

    // Install network stack
    InternetStackHelper netStack;
    netStack.Install(netNodes);

    // Assign IP addresses
    Ipv4AddressHelper ipAllocator;
    ipAllocator.SetBase("192.168.0.0", "255.255.255.0");
    ipAllocator.Assign(linkA_B);
    ipAllocator.SetBase("192.168.1.0", "255.255.255.0");
    Ipv4InterfaceContainer ifB_C = ipAllocator.Assign(linkB_C);

    netNodes.Get(1)->GetObject<Ipv4>()->SetAttribute("IpForward", BooleanValue(true));
    Ipv4GlobalRoutingHelper::PopulateRoutingTables();

    // ---------------- UDP FLOW ----------------
    uint16_t udpPort = 6002;
    UdpServerHelper udpSink(udpPort);
    ApplicationContainer udpServerApp = udpSink.Install(netNodes.Get(1));
    udpServerApp.Start(Seconds(1.0));
    udpServerApp.Stop(Seconds(10.0));

    UdpClientHelper udpClient(ifB_C.GetAddress(0), udpPort);
    udpClient.SetAttribute("MaxPackets", UintegerValue(5000));  // more packets
    udpClient.SetAttribute("Interval", TimeValue(MilliSeconds(2))); // faster rate
    udpClient.SetAttribute("PacketSize", UintegerValue(1024));
    ApplicationContainer udpClientApp = udpClient.Install(netNodes.Get(0));
    udpClientApp.Start(Seconds(2.0));
    udpClientApp.Stop(Seconds(9.0));

    // ---------------- TCP FLOW ----------------
    uint16_t tcpPort = 7002;
    PacketSinkHelper tcpSink("ns3::TcpSocketFactory", InetSocketAddress(Ipv4Address::GetAny(), tcpPort));
    ApplicationContainer tcpSinkApp = tcpSink.Install(netNodes.Get(2));
    tcpSinkApp.Start(Seconds(1.0));
    tcpSinkApp.Stop(Seconds(10.0));

    BulkSendHelper tcpSender("ns3::TcpSocketFactory", InetSocketAddress(ifB_C.GetAddress(1), tcpPort));
    tcpSender.SetAttribute("MaxBytes", UintegerValue(0)); // unlimited
    ApplicationContainer tcpClientApp = tcpSender.Install(netNodes.Get(0));
    tcpClientApp.Start(Seconds(2.0));
    tcpClientApp.Stop(Seconds(9.0));

    // ---------------- PCAP Tracing ----------------
    // Create output directory first: mkdir -p scratch/q2
    p2pLink.EnablePcap("scratch/q2/udp_flow", linkA_B);
    p2pLink.EnablePcap("scratch/q2/tcp_flow", linkB_C);

    // ---------------- Flow Monitoring ----------------
    FlowMonitorHelper flowHelper;
    Ptr<FlowMonitor> monitor = flowHelper.InstallAll();

    Simulator::Stop(Seconds(10.0));
    Simulator::Run();

    monitor->CheckForLostPackets();
    auto stats = monitor->GetFlowStats();

    std::cout << "Flow Summary:\n";
    for (auto &entry : stats) {
        std::ostringstream flowInfo;
        flowInfo << "Flow ID " << entry.first
                 << " -- Rx: " << (entry.second.rxBytes * 8.0 / 9.0 / 1e6) << " Mbps | "
                 << "Lost Packets: " << entry.second.lostPackets
                 << " | Delay Avg: " << (entry.second.delaySum.GetSeconds() / entry.second.rxPackets) << " s";
        std::cout << flowInfo.str() << std::endl;
    }

    Simulator::Destroy();
    return 0;
}
