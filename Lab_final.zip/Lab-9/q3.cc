#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/flow-monitor-module.h"

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("SubnetCommRouting");

int main(int argc, char *argv[]) {
    // Node layout: Sender → Router → Receiver
    NodeContainer sender, router, receiver;
    sender.Create(1);
    router.Create(1);
    receiver.Create(1);

    // Establish point-to-point links
    PointToPointHelper p2p;
    p2p.SetDeviceAttribute("DataRate", StringValue("5Mbps"));
    p2p.SetChannelAttribute("Delay", StringValue("2ms"));

    NetDeviceContainer dev1 = p2p.Install(sender.Get(0), router.Get(0));
    NetDeviceContainer dev2 = p2p.Install(router.Get(0), receiver.Get(0));

    // Install the protocol stack on all devices
    InternetStackHelper netstack;
    netstack.InstallAll();

    // Enable IP forwarding on router
    router.Get(0)->GetObject<Ipv4>()->SetAttribute("IpForward", BooleanValue(true));

    // Assign IPs to both segments
    Ipv4AddressHelper address;
    address.SetBase("10.1.1.0", "255.255.255.0");
    Ipv4InterfaceContainer iface1 = address.Assign(dev1);

    address.SetBase("10.1.2.0", "255.255.255.0");
    Ipv4InterfaceContainer iface2 = address.Assign(dev2);

    // Static routing configuration
    Ipv4StaticRoutingHelper staticRouting;

    Ptr<Ipv4StaticRouting> sRoute = staticRouting.GetStaticRouting(sender.Get(0)->GetObject<Ipv4>());
    sRoute->SetDefaultRoute(iface1.GetAddress(1), 1);

    Ptr<Ipv4StaticRouting> rRoute = staticRouting.GetStaticRouting(receiver.Get(0)->GetObject<Ipv4>());
    rRoute->SetDefaultRoute(iface2.GetAddress(0), 1);

    // Application layer: UDP Server on Receiver
    uint16_t udpPort = 5000;
    UdpServerHelper udpSink(udpPort);
    ApplicationContainer sinkApp = udpSink.Install(receiver.Get(0));
    sinkApp.Start(Seconds(1.0));
    sinkApp.Stop(Seconds(10.0));

    // UDP Client on Sender
    UdpClientHelper udpSource(iface2.GetAddress(1), udpPort);
    udpSource.SetAttribute("MaxPackets", UintegerValue(500));
    udpSource.SetAttribute("Interval", TimeValue(MilliSeconds(20)));
    udpSource.SetAttribute("PacketSize", UintegerValue(1024));

    ApplicationContainer sourceApp = udpSource.Install(sender.Get(0));
    sourceApp.Start(Seconds(2.0));
    sourceApp.Stop(Seconds(9.0));

    // Enable packet capture for Wireshark
    p2p.EnablePcapAll("scratch/q3/inter_subnet_routing");

    // Setup flow monitor
    FlowMonitorHelper monitorHelper;
    Ptr<FlowMonitor> monitor = monitorHelper.InstallAll();

    // Run simulation
    Simulator::Stop(Seconds(10.0));
    Simulator::Run();

    // Analyze flow results
    monitor->CheckForLostPackets();
    Ptr<Ipv4FlowClassifier> flowClassifier = DynamicCast<Ipv4FlowClassifier>(monitorHelper.GetClassifier());
    auto flowStats = monitor->GetFlowStats();

    std::cout << "\n======= Traffic Flow Report =======\n";
    for (const auto& entry : flowStats) {
        Ipv4FlowClassifier::FiveTuple flow = flowClassifier->FindFlow(entry.first);
        std::cout << "Flow ID: " << entry.first << "\n";
        std::cout << "  Source:      " << flow.sourceAddress << "\n";
        std::cout << "  Destination: " << flow.destinationAddress << "\n";
        std::cout << "  Packets Sent:     " << entry.second.txPackets << "\n";
        std::cout << "  Packets Received: " << entry.second.rxPackets << "\n";
        std::cout << "  Lost Packets:     " << entry.second.lostPackets << "\n";
        std::cout << "  Avg Throughput:   " 
                  << (entry.second.rxBytes * 8.0 / 9.0 / 1000) << " Kbps\n\n";
    }

    Simulator::Destroy();
    return 0;
}
