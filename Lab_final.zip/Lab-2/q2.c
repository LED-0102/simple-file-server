#include <stdio.h>
#include <string.h>
#include <stdbool.h>
bool isComment(const char *line) {
// Remove leading whitespaces
while (*line == ' ' || *line == '\t') {
line++;
}
// Check for single-line comment
if (line[0] == '/' && line[1] == '/') {
return true;
}
// Check for multi-line comment
if (line[0] == '/' && line[1] == '*') {
// Check for closing '*/'
const char *end = strstr(line, "*/");
return (end != NULL);
}
return false;
}
int main() {
char line[256];
printf("Enter a line of text: \n");
fgets(line, sizeof(line), stdin);
// Remove newline character if present
size_t len = strlen(line);
if (len > 0 && line[len - 1] == '\n') {
line[len - 1] = '\0';
}
if (isComment(line)) {
printf("The line is a comment.\n");
} else {
printf("The line is NOT a comment.\n");
}
return 0;
}