#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/flow-monitor-module.h"

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("ThreeNodeTopology");

int main(int argc, char *argv[]) {
    // Enable Logging
    LogComponentEnable("UdpClient", LOG_LEVEL_INFO);
    LogComponentEnable("UdpServer", LOG_LEVEL_INFO);

    // Create 3 Nodes
    NodeContainer nodes;
    nodes.Create(3);

    // Setup point-to-point links
    PointToPointHelper p2p;
    p2p.SetDeviceAttribute("DataRate", StringValue("1Mbps"));
    p2p.SetChannelAttribute("Delay", StringValue("1ms"));  // Adjust for latency variation

    NetDeviceContainer dev0_1 = p2p.Install(nodes.Get(0), nodes.Get(1));
    NetDeviceContainer dev1_2 = p2p.Install(nodes.Get(1), nodes.Get(2));

    // Install Internet Stack
    InternetStackHelper stack;
    stack.Install(nodes);

    // Enable IP forwarding on Node1
    Ptr<Ipv4> ipv4Node1 = nodes.Get(1)->GetObject<Ipv4>();
    ipv4Node1->SetAttribute("IpForward", BooleanValue(true));

    // Assign IP Addresses Correctly
    Ipv4AddressHelper ipv4;
    
    ipv4.SetBase("10.1.1.0", "255.255.255.0");
    Ipv4InterfaceContainer interfaces0_1 = ipv4.Assign(dev0_1);

    ipv4.SetBase("10.1.2.0", "255.255.255.0");
    Ipv4InterfaceContainer interfaces1_2 = ipv4.Assign(dev1_2);

    // Populate Routing Tables AFTER IP Assignment
    Ipv4GlobalRoutingHelper::PopulateRoutingTables();

    // Setup UDP Server on Node2 (Port 5000)
    UdpServerHelper server1(5000);
    ApplicationContainer serverApp1 = server1.Install(nodes.Get(2));
    serverApp1.Start(Seconds(1.0));
    serverApp1.Stop(Seconds(10.0));

    // Setup UDP Client on Node0 → Node2 (Port 5000)
    UdpClientHelper client1(interfaces1_2.GetAddress(1), 5000);
    client1.SetAttribute("MaxPackets", UintegerValue(1000));
    client1.SetAttribute("Interval", TimeValue(MilliSeconds(10)));
    client1.SetAttribute("PacketSize", UintegerValue(1024));
    ApplicationContainer clientApp1 = client1.Install(nodes.Get(0));
    clientApp1.Start(Seconds(2.0));
    clientApp1.Stop(Seconds(9.0));

    // Setup Second UDP Server (Port 5001)
    UdpServerHelper server2(5001);
    ApplicationContainer serverApp2 = server2.Install(nodes.Get(2));
    serverApp2.Start(Seconds(1.0));
    serverApp2.Stop(Seconds(10.0));

    // Setup Second UDP Client on Node0 → Node2 (Port 5001)
    UdpClientHelper client2(interfaces1_2.GetAddress(1), 5001);
    client2.SetAttribute("MaxPackets", UintegerValue(1000));
    client2.SetAttribute("Interval", TimeValue(MilliSeconds(10)));
    client2.SetAttribute("PacketSize", UintegerValue(1024));
    ApplicationContainer clientApp2 = client2.Install(nodes.Get(0));
    clientApp2.Start(Seconds(2.0));
    clientApp2.Stop(Seconds(9.0));

    // Enable PCAP Tracing (Now Fully Correct)
    p2p.EnablePcap("scratch/exp1-node0", dev0_1.Get(0), true);  // Node0 → Node1
    p2p.EnablePcap("scratch/exp1-node1-rx", dev0_1.Get(1), true);  // Node1 receiving from Node0

    p2p.EnablePcap("scratch/exp1-node1-tx", dev1_2.Get(0), true);  // Node1 forwarding to Node2
    p2p.EnablePcap("scratch/exp1-node2", dev1_2.Get(1), true);  // Node2 receiving from Node1

    // Flow Monitor for Throughput Measurement
    FlowMonitorHelper flowMon;
    Ptr<FlowMonitor> monitor = flowMon.InstallAll();

    // Set explicit simulation stop time
    Simulator::Stop(Seconds(10.0));
    
    Simulator::Run();

    // Compute Throughput After Simulation Ends
    monitor->CheckForLostPackets();
    Ptr<Ipv4FlowClassifier> classifier = DynamicCast<Ipv4FlowClassifier>(flowMon.GetClassifier());
    std::map<FlowId, FlowMonitor::FlowStats> stats = monitor->GetFlowStats();

    for (auto it = stats.begin(); it != stats.end(); ++it) {
        Ipv4FlowClassifier::FiveTuple t = classifier->FindFlow(it->first);
        std::cout << "Flow " << it->first << " (" << t.sourceAddress << " -> " << t.destinationAddress << ")\n";
        std::cout << "  Tx Bytes: " << it->second.txBytes << "\n";
        std::cout << "  Rx Bytes: " << it->second.rxBytes << "\n";
        std::cout << "  Throughput: " << (it->second.rxBytes * 8.0 / 9.0 / 1000) << " Kbps\n";  // 9s transfer time
    }

    Simulator::Destroy();
    return 0;
}
