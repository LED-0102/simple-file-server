#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <fcntl.h>

#define SERVER_IP "127.0.0.1"
#define PORT 8080
#define BUFFER_SIZE 50

void count_bytes_words(char *filename) {
    int file_fd = open(filename, O_RDONLY);
    if (file_fd < 0) {
        perror("Failed to open received file");
        exit(EXIT_FAILURE);
    }

    char buffer[BUFFER_SIZE];
    ssize_t bytes_read;
    int byte_count = 0, word_count = 0;
    char prev = ' ';
    
    while ((bytes_read = read(file_fd, buffer, BUFFER_SIZE)) > 0) {
        byte_count += bytes_read;
        for (int i = 0; i < bytes_read; i++) {
            if (strchr(",;:. \t", buffer[i]) && !strchr(",;:. \t", prev)) {
                word_count++;
            }
            prev = buffer[i];
        }
    }
    if (!strchr(",;:. \t", prev)) {
        word_count++;
    }

    printf("The file transfer is successful. Size of the file = %d bytes, no. of words = %d\n", byte_count, word_count);
    close(file_fd);
}

int main() {
    int sock_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (sock_fd < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr);

    if (connect(sock_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        exit(EXIT_FAILURE);
    }

    char filename[BUFFER_SIZE];
    printf("Enter filename: ");
    fgets(filename, BUFFER_SIZE, stdin);
    filename[strcspn(filename, "\n")] = 0;
    
    write(sock_fd, filename, strlen(filename) + 1);

    char buffer[BUFFER_SIZE];
    ssize_t bytes_received = read(sock_fd, buffer, BUFFER_SIZE);
    if (bytes_received <= 0) {
        printf("ERR 01: File Not Found\n");
        close(sock_fd);
        exit(EXIT_FAILURE);
    }

    char *ext = strrchr(filename, '.');
    if (!ext) {
        ext = ".txt"; // Default extension if none found
    }

    char received_filename[BUFFER_SIZE];
    snprintf(received_filename, BUFFER_SIZE, "received_file%s", ext);
    
    int file_fd = open(received_filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (file_fd < 0) {
        perror("Failed to create file");
        exit(EXIT_FAILURE);
    }

    write(file_fd, buffer, bytes_received);
    while ((bytes_received = read(sock_fd, buffer, BUFFER_SIZE)) > 0) {
        write(file_fd, buffer, bytes_received);
    }

    close(file_fd);
    close(sock_fd);

    count_bytes_words(received_filename);
    return 0;
}